//
//  ViewController.swift
//  App-3
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txt_name: UITextField!
    
    @IBOutlet weak var txt_sub: UITextField!
    
    @IBOutlet weak var txt_city: UITextField!
    
    @IBOutlet weak var lbl_nm: UILabel!
    
    @IBOutlet weak var lbl_sub: UILabel!
    
    @IBOutlet weak var lbl_city: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btn_add(_ sender: Any) {
        lbl_nm.text=txt_name.text
        lbl_sub.text=txt_sub.text
        lbl_city.text=txt_city.text
    }
}

