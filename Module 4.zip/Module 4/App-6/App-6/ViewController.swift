//
//  ViewController.swift
//  App-6
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var myimg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

