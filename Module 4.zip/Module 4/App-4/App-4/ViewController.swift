//
//  ViewController.swift
//  App-4
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btn_hide(_ sender: Any) {
        lbl .isHidden
    }
}

