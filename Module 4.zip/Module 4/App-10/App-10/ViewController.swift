//
//  ViewController.swift
//  App-10
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {
    
    var dtpkr = UIDatePicker()
    
    @IBOutlet weak var txt_date: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        dtpkr.preferredDatePickerStyle = .wheels
        txt_date.inputView=dtpkr
        
        dtpkr.addTarget(self, action: #selector(ViewController.selectdata), for: .valueChanged)
    }
    
    @objc func selectdata()
    {
        let dt=dtpkr.date
        let dtfrm=DateFormatter()
        dtfrm.dateStyle = .full
        txt_date.text=dtfrm.string(from: dt)
        view.endEditing(true)
    }


}

