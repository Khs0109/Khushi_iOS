//
//  ViewController.swift
//  App-7
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var my_img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_add(_ sender: Any) {
        /*let photo=UIImagePickerController()
        photo.delegate=self
        photo.sourceType = .camera
        present(photo, animated: true, completion: nil)*/
        
        let alert=UIAlertController(title: "Select one option!", message: "Please choose any one Source!", preferredStyle:.actionSheet)
        let btn1=UIAlertAction(title: "From Camera", style:.destructive, handler:{ACTION in
            
            let photo=UIImagePickerController()
            photo.delegate=self
            photo.sourceType = .camera
            self.present(photo, animated: true, completion: nil)
        })
        let btn2=UIAlertAction(title: "From Photo Album", style: .default, handler: {ACTION in
            
            let photo=UIImagePickerController()
            photo.delegate=self
            self.present(photo, animated: true, completion: nil)
        })
        let btn3=UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(btn1)
        alert.addAction(btn2)
        alert.addAction(btn3)
        present(alert, animated: true, completion: nil)
    }
    
}

extension ViewController:UIImagePickerControllerDelegate,UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        let img=info[.originalImage] as! UIImage
        my_img.image=img
        dismiss(animated: true, completion: nil)
        
    }
}


