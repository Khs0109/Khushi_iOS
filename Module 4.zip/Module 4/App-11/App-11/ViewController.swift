//
//  ViewController.swift
//  App-11
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {
    
    var subpkr = UIPickerView()

    @IBOutlet weak var txt_sub: UITextField!
    
    var sub = [""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sub = ["iOS","Android","JAVA","C++","C#","React JS","PHP","OS","SEO",".Net"]
        
        // Do any additional setup after loading the view.
        
        subpkr.dataSource=self
        subpkr.delegate=self
        txt_sub.inputView=subpkr
    }


}

extension ViewController:UIPickerViewDataSource,UIPickerViewDelegate
{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return sub.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return sub[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        txt_sub.text=sub[row]
        view.endEditing(true)
    }
    
}

