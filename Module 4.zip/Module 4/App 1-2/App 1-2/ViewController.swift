//
//  ViewController.swift
//  App 1-2
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txt_name: UITextField!
    
    @IBOutlet weak var txt_mail: UITextField!
    
    @IBOutlet weak var txt_psw: UITextField!
    
    @IBOutlet weak var txt_cnfpsw: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_signup(_ sender: Any)
    {
        let HomeVC=storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeViewController
        navigationController?.pushViewController(HomeVC, animated: true)
        
    }
    
    @IBAction func btn_login(_ sender: Any)
    {
        let SecondVC=storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondViewController
        navigationController?.pushViewController(SecondVC, animated: true)
         
        
        
    }
}

